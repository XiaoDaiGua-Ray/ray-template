const r="/ray-template/svg/ray-BrETrDeA.svg";export{r as L};
