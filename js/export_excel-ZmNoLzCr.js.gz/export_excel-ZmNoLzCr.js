const e="/ray-template/svg/export_excel-Re1cVpta.svg";export{e as default};
