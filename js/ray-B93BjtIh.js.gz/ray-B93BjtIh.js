const a="/ray-template/svg/ray-BrETrDeA.svg";export{a as default};
