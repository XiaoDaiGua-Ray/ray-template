import{g as c}from"./call-bind-apply-helpers@1.0.1-D6-XlEtG.js";var n={exports:{}};/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/var a;function p(){return a||(a=1,function(o){(function(){var f={}.hasOwnProperty;function e(){for(var t="",r=0;r<arguments.length;r++){var s=arguments[r];s&&(t=i(t,u(s)))}return t}function u(t){if(typeof t=="string"||typeof t=="number")return t;if(typeof t!="object")return"";if(Array.isArray(t))return e.apply(null,t);if(t.toString!==Object.prototype.toString&&!t.toString.toString().includes("[native code]"))return t.toString();var r="";for(var s in t)f.call(t,s)&&t[s]&&(r=i(r,s));return r}function i(t,r){return r?t?t+" "+r:t+r:t}o.exports?(e.default=e,o.exports=e):window.classNames=e})()}(n)),n.exports}var l=p();const x=c(l);export{x as c};
