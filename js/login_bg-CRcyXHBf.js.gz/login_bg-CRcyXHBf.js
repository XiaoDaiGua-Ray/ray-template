const g="/ray-template/svg/login_bg-CH0AhDTq.svg";export{g as default};
